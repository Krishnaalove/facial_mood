# FaceMood Enhanced

Steps:
1. Install requirements.
2. Run `python app.py`.
