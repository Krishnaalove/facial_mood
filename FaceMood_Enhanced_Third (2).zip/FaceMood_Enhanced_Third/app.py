import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load emotion model
model = load_model("fer_model.h5", compile=False)

# Emotion labels (adjust order if your model is different)
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

# Load Haar Cascade
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
if face_cascade.empty():
    print("Error: Haar cascade not loaded properly!")
    exit()

# Load DNN face detector (fallback)
dnn_model = cv2.dnn.readNetFromCaffe(
    cv2.data.haarcascades + "deploy.prototxt.txt",
    cv2.data.haarcascades + "res10_300x300_ssd_iter_140000.caffemodel"
)

# Start webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

print("Facial Emotion Detection is running... Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Mirror effect
    frame = cv2.flip(frame, 1)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Try Haarcascade first
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.05,
        minNeighbors=3,
        minSize=(20, 20)
    )

    # If Haar fails → try DNN
    if len(faces) == 0:
        (h, w) = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 1.0,
                                     (300, 300), (104.0, 177.0, 123.0))
        dnn_model.setInput(blob)
        detections = dnn_model.forward()

        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > 0.6:  # confidence threshold
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x1, y1, x2, y2) = box.astype("int")
                faces.append((x1, y1, x2 - x1, y2 - y1))

    print("Faces found:", len(faces))  # debug info

    # Process detected faces
    for (x, y, w, h) in faces:
        roi_gray = gray[y:y+h, x:x+w]
        try:
            roi_gray = cv2.resize(roi_gray, (48, 48))
        except:
            continue

        roi = roi_gray.astype('float') / 255.0
        roi = np.expand_dims(roi, axis=0)
        roi = np.expand_dims(roi, axis=-1)

        # Predict emotion
        preds = model.predict(roi, verbose=0)
        emotion = emotion_labels[np.argmax(preds)]

        # Draw results
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame, emotion, (x, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

    # Show output
    cv2.imshow("Facial Emotion Detection", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
